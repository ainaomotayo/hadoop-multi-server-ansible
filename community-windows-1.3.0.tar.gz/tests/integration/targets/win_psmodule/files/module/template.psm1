Function --- FUNCTION --- {
    return [PSCustomObject]@{
        Name = "--- NAME ---"
        Version = "--- VERSION ---"
        Repo = "--- REPO ---"
    }
}

Export-ModuleMember -Function --- FUNCTION ---

