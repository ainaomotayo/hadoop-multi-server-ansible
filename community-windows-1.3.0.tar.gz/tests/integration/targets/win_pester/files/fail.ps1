# This makes sure that a file that does not end with *.test.ps1 does not run
throw "should never fail"
